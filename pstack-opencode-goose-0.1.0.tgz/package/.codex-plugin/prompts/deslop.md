---
name: deslop
description: deslop a diff before commit
disable-model-invocation: true
---

Invoke the `deslop` skill and follow it. Resolve Claude tool names, Claude model names, and Claude built-in skills through `poteto-mode/references/codex-tools.md`, including its Per-skill notes.
